
package bmi.body.test;
import java.util.Scanner;

public class BMIBodyTest {

   
    public static void main(String[] args) {
      Scanner input = new Scanner(System.in);
        System.out.println("please enteer your BMI");
        double BMI = input.nextDouble();
        
        if(BMI<18.5){
            System.out.println("underwight");
        }else if(BMI>=18.5 && BMI<25.0){
            System.out.println("normal");
        }else if(BMI>=25.0  &&  BMI<30){
            System.out.println("overwight");
        }else{
            System.out.println("obese");
        }
    }
    
}
