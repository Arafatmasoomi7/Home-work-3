
package random.program;

import java.util.Scanner;


public class RandomProgram {

   
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    int number1 = (int) (Math.random() *10) , number2 = (int) (Math.random() *10);
    double minus = number1 - number2;
    
    double userinput;
        System.out.println("what is the result of "+ number1 + "-" + number2);
        userinput = input.nextDouble();
        
        if(userinput == minus){
            System.out.println("your answer is correct");
        }else{
            System.out.println("your answer ic incorrect");
            
        }
    }
    
}
